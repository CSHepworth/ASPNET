using Microsoft.AspNetCore.Mvc;
namespace testfire0.Controllers;
    public class HelloController : Controller
    {
        [HttpGet]
        [Route("")]
        public string Index()
        {
            return "This is my Index";
        }

        [HttpGet("projects")]
        public string Projects()
        {
            return "These are my projects";
        }

        [HttpGet("contacts")]
        public string Contacts()
        {
            return "These are my contacts";
        }

    }